import time, math

start: float = time.time()
i: int = 1
while time.time() - start < 1.0:
    math.log(i)
    i += 1
print(str(i)+" operations in: "+str(time.time()-start)+"s.")